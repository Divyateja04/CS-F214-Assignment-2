var _task_8c =
[
    [ "max", "_task_8c.html#a2e1da8593b0244d8e9e3b84ef7b35e73", null ],
    [ "andElimination", "_task_8c.html#a3323c3f020ae77873b9cbc407805b44d", null ],
    [ "andIntroduction", "_task_8c.html#a3195556875cb6b03ee686b34f9de1c81", null ],
    [ "implicationElimination", "_task_8c.html#a330ae2ed73e6946e15a1f955b3e8374f", null ],
    [ "main", "_task_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "MT", "_task_8c.html#a533dcc1368d1a4e5f17bbcc141c8fd60", null ],
    [ "orIntroduction", "_task_8c.html#a28ec98df91fbb88586cde2f15108c055", null ]
];