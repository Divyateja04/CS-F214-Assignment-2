var searchData=
[
  ['andelimination_0',['andElimination',['../_task_8c.html#a3323c3f020ae77873b9cbc407805b44d',1,'Task.c']]],
  ['andintroduction_1',['andIntroduction',['../_task_8c.html#a3195556875cb6b03ee686b34f9de1c81',1,'Task.c']]]
];
