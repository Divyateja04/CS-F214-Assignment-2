var searchData=
[
  ['main_0',['main',['../_task_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'Task.c']]],
  ['mt_1',['MT',['../_task_8c.html#a533dcc1368d1a4e5f17bbcc141c8fd60',1,'Task.c']]]
];
