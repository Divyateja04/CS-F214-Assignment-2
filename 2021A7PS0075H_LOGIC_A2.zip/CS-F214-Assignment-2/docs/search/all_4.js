var searchData=
[
  ['orintroduction_0',['orIntroduction',['../_task_8c.html#a28ec98df91fbb88586cde2f15108c055',1,'Task.c']]]
];
