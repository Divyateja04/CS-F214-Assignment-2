var files_dup =
[
    [ "Task.c", "_task_8c.html", "_task_8c" ]
];